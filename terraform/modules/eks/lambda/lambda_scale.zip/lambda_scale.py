import boto3
import os
import logging

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    try:
        # Read environment variables
        cluster_name = os.environ.get('CLUSTER_NAME')
        nodegroup_name = os.environ.get('NODEGROUP_NAME')
        min_size = int(os.environ.get('MIN_SIZE', '0'))  # Default to 0 if not set
        max_size = int(os.environ.get('MAX_SIZE', '0'))  # Default to 0 if not set
        desired_size = int(os.environ.get('DESIRED_SIZE', '0'))  # Default to 0 if not set

        logger.info(f"Updating nodegroup config for cluster: {cluster_name}, nodegroup: {nodegroup_name}")
        logger.info(f"Desired Config - Min Size: {min_size}, Max Size: {max_size}, Desired Size: {desired_size}")

        # Use the Boto3 client
        client = boto3.client('eks')
        response = client.update_nodegroup_config(
            clusterName=cluster_name,
            nodegroupName=nodegroup_name,
            scalingConfig={
                'minSize': min_size,
                'maxSize': max_size,
                'desiredSize': desired_size
            }
        )
        
        logger.info("Update successful.")
        logger.info(f"Response: {response}")
        return response

    except Exception as e:
        logger.error("An error occurred while updating the nodegroup config.")
        logger.error(str(e))
        raise
